#!/bin/bash

# Checking, if input file exists
if [ ! -f "input.txt" ]; then
    echo "Error: input.txt not found!"
    exit 1
fi

# Output file
output_file="output.txt"
> "$output_file"  # Clear output file if exists

# Read input file line by line
while read -r line; do
    # Extracting  only the required parameters
    if [[ $line == *'"frame.time": '* ]]; then
        echo "$line" >> "$output_file"
    elif [[ $line == *'"wlan.fc.type": '* ]]; then
        echo "$line" >> "$output_file"
    elif [[ $line == *'"wlan.fc.subtype": '* ]]; then
        echo "$line" >> "$output_file"
    fi
done < "input.txt"

echo "Processing completed. Output saved in output.txt"

