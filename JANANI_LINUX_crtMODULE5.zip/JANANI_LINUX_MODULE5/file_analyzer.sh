#!/bin/bash

ERROR_LOG="errors.log"
> "$ERROR_LOG"  # Clear previous log

# Recursive function
search_files() {
    local dir="$1"
    local keyword="$2"
    
    for file in "$dir"/*; do
        if [ -d "$file" ]; then
            search_files "$file" "$keyword"  # Recurse into subdirectories
        elif [ -f "$file" ]; then
            if grep -q "$keyword" "$file"; then
                echo "Found in: $file"
                grep --color=always "$keyword" "$file"
            fi
        fi
    done
}

# Display help menu
show_help() {
    cat << EOF
Usage: $0 [options]
Options:
  -d <directory>   Search for a keyword recursively in a directory.
  -f <file>        Search for a keyword in a specific file.
  -k <keyword>     Keyword to search for.
  --help           Display this help menu.
Examples:
  $0 -d logs -k error
  $0 -f script.sh -k TODO
EOF
}

# Validate inputs
validate_inputs() {
    if [ -z "$keyword" ]; then
        echo "Error: Keyword cannot be empty" | tee -a "$ERROR_LOG"
        exit 1
    fi
    if [[ "$keyword" =~ [^a-zA-Z0-9_-] ]]; then
        echo "Error: Invalid keyword format" | tee -a "$ERROR_LOG"
        exit 1
    fi
    if [ -n "$file" ] && [ ! -f "$file" ]; then
        echo "Error: File '$file' not found" | tee -a "$ERROR_LOG"
        exit 1
    fi
    if [ -n "$directory" ] && [ ! -d "$directory" ]; then
        echo "Error: Directory '$directory' not found" | tee -a "$ERROR_LOG"
        exit 1
    fi
}

# Parse arguments
while getopts ":d:f:k:-:" opt; do
    case $opt in
        d) directory="$OPTARG" ;;
        f) file="$OPTARG" ;;
        k) keyword="$OPTARG" ;;
        -)
            case "$OPTARG" in
                help) show_help; exit 0 ;;
                *) echo "Invalid option: --$OPTARG" | tee -a "$ERROR_LOG"; exit 1 ;;
            esac
            ;;
        ?) echo "Invalid option: -$OPTARG" | tee -a "$ERROR_LOG"; exit 1 ;;
    esac
done

# Special parameters 
echo "Script Name: $0"
echo "Total Arguments: $#"
echo "Arguments List: $@"

# Validate inputs
validate_inputs

# Execute search based on input
echo "Execution started..."
if [ -n "$directory" ]; then
    echo "Searching for '$keyword' in directory '$directory'..."
    search_files "$directory" "$keyword"
elif [ -n "$file" ]; then
    echo "Searching for '$keyword' in file '$file'..."
    grep --color=always "$keyword" <<< "$(cat "$file")"

else
    echo "Error: No valid options provided" | tee -a "$ERROR_LOG"
    show_help
    exit 1
fi
echo "Execution completed with exit status: $?"

